[ -z "$BASH" ] || [ "$BASH" = /bin/sh ] || [ \! -s /etc/bash.bashrc ] || . /etc/bash.bashrc
