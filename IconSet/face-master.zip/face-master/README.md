![示例](https://raw.githubusercontent.com/Orz-3/mini/none/yaofan.png)

![示例](https://raw.githubusercontent.com/Orz-3/face/master/头部.png)

## face图标包

图片地址：https://raw.githubusercontent.com/Orz-3/face/master/name.png

请将上方地址中的name替换成图标的实际文件名

文件名对照：

![Alt text](https://raw.githubusercontent.com/Orz-3/face/master/%E7%A4%BA%E4%BE%8B.png)

免责声明：本项目为免费分享使用，仅用于iOS网络调试软件Quantumult X的图标包。部分图修改自网络图片，如有侵权请联系我，将立即删除侵权内容。
